﻿Option Explicit On
Option Compare Binary

Public Class StringReader

    '
    '   Simple string reader class
    '

    '
    '   Current position. The first position is 1.
    '
    Public CurrentPosition As Long

    Private mstrInputString As String

    Public Sub New(ByVal InputString As String)
        MyBase.New()
        Me.InputString = InputString
    End Sub
    '
    '   Input string
    '
    Public Property InputString() As String
        Get
            Return mstrInputString
        End Get
        Set(ByVal value As String)
            mstrInputString = value
            CurrentPosition = 1
        End Set
    End Property

    '
    '   Returns specified number of characters starting at the current position and advances the current position by the length of the
    '   returned value.
    '
    '   If there are fewer than Count characters at the current position in the input string only the available characters are returned.
    '   If this function is called when EndOfString is true then an empty string is returned.
    '
    Public Function GetChars(ByVal Count As Integer) As String
        Dim Chars As String

        Chars = PeekChars(Count)
        Advance(Len(Chars))
        GetChars = Chars
    End Function

    '
    '   Returns specified number of characters starting at the current position. Does not advance the current position.
    '
    '   If there are fewer than Count characters at the current position in the input string only the available characters are returned.
    '   If this function is called when EndOfString is true then an empty string is returned.
    '
    Public Function PeekChars(ByVal Count As Integer) As String
        Dim Chars As String
        Dim Index As Long

        Chars = ""
        Index = CurrentPosition
        While Count > 0 And Not EndOfString
            Chars = Chars & Mid(InputString, Index, 1)
            Index = Index + 1
            Count = Count - 1
        End While
        PeekChars = Chars
    End Function

    '
    '   Returns the remainder of the string starting at the current position. The current position is not changed.
    '
    Public Function PeekRemainder() As String
        If EndOfString() Then
            PeekRemainder = ""
        Else
            PeekRemainder = Mid(mstrInputString, CurrentPosition)
        End If
    End Function

    '
    '   Advance the current position by the specified number of positions.
    '
    Public Sub Advance(ByVal Count As Integer)
        While Count > 0 And Not EndOfString
            CurrentPosition = CurrentPosition + 1
            Count = Count - 1
        End While
    End Sub

    '
    '   Returns all the characters from the current position up to but not including the beginning of the specified terminator
    '   string, or the remainder of the string if the terminator string is not found. If the terminator string is found then
    '   the reader is positioned at the position of the first character in the terminator string.
    '
    Public Function GetStringBefore(ByVal Terminator As String) As String
        Dim Value As String

        Value = ""
        While Not EndOfString
            If PeekChars(Len(Terminator)) = Terminator Then
                GetStringBefore = Value
                Exit Function
            End If
            Value = Value & GetChars(1)
        End While
        GetStringBefore = Value
    End Function

    '
    '   Returns True if the current position is beyond the end of the string
    '
    Public ReadOnly Property EndOfString() As Boolean
        Get
            Return (CurrentPosition > Len(InputString))
        End Get
    End Property
End Class
