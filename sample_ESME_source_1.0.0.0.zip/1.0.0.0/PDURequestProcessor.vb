﻿Imports tssmpplib

Public Class PDURequestProcessor
    Implements ITSPDURequestProcessor

    Private mcolParameters As Dictionary(Of String, String)

    Public Sub InitialiseProcessor(ByVal Parameters As Dictionary(Of String, String)) Implements tssmpplib.ITSPDURequestProcessor.InitialiseProcessor
        mcolParameters = Parameters
        TraceEnabled = CBool(GetParameterValue("Trace", "False"))
        TraceLine("InitialiseProcessor", "")
        For Each Item In Parameters
            TraceLine("InitialiseProcessor", Item.Key & " = " & Item.Value)
        Next
    End Sub

    Public Function ProcessRequest(ByVal objRequestPDU As tssmpplib.PDU) As tssmpplib.PDU Implements tssmpplib.ITSPDURequestProcessor.ProcessRequest
        TraceLine("ProcessRequest", "CommandName = " & objRequestPDU.CommandName)
        Select Case objRequestPDU.CommandName
            Case "deliver_sm"
                Return ProcessDeliverSMRequest(objRequestPDU)

            Case Else
                Throw New Exception("PDU type '" & objRequestPDU.CommandName & "' not supported")
        End Select
    End Function

    Public Sub StopProcessor() Implements tssmpplib.ITSPDURequestProcessor.StopProcessor
        TraceLine("StopProcessor", "")
    End Sub

    Private Function ProcessDeliverSMRequest(ByVal objRequestPDU As PDU) As PDU
        Try
            TraceLine("ProcessDeliverSMRequest", "RequestPDU = " & objRequestPDU.ToString())
            '
            '   Here we do the actual processing required to issue a token.
            '
            Dim ResponseMessage As String
            Try
                '
                '   Extract the required parameters from the deliver_sm request
                '
                Dim ShortMessage As Object = objRequestPDU.GetParameterValue("short_message")
                TraceLine("ProcessDeliverSMRequest", "short_message = 0x" & BytesAsHex(ShortMessage))
                Dim RequestMessage As String
                Dim DataCoding As Byte = objRequestPDU.GetParameterValue("data_coding")
                TraceLine("ProcessDeliverSMRequest", "data_coding = 0x" & AsHex(DataCoding, 2))
                Select Case DataCoding
                    Case &H4 ' Octet (UTF-8?)
                        RequestMessage = System.Text.Encoding.UTF8.GetString(ShortMessage)

                    Case &H8 ' UCS-2
                        RequestMessage = objRequestPDU.ConvertFromUCS2(ShortMessage)

                    Case Else
                        Throw New Exception("data_coding value 0x" & AsHex(DataCoding, 2) & " not supported")
                End Select
                '
                '   Process request
                '
                TraceLine("ProcessDeliverSMRequest", "RequestMessage = " & RequestMessage)
                '
                '   ************* Perform message processing here ***************
                '
                ResponseMessage = "put response here"
                TraceLine("ProcessDeliverSMRequest", "ResponseMessage = " & ResponseMessage)
            Catch ex As Exception
                ResponseMessage = GetParameterValue("Error.System", "Request processing failed")
            End Try
            '
            '   Send the response message to the originating SME using submit_sm command
            '
            TraceLine("ProcessDeliverSMRequest", "ResponseMessage = " & ResponseMessage)
            Dim objResponsePDU = New PDU("submit_sm")
            With objResponsePDU
                .SetParameterValue("service_type", "")
                .SetParameterValue("source_addr_ton", objRequestPDU.GetParameterValue("dest_addr_ton"))
                .SetParameterValue("source_addr_npi", objRequestPDU.GetParameterValue("dest_addr_npi"))
                .SetParameterValue("source_addr", "555")
                .SetParameterValue("dest_addr_ton", objRequestPDU.GetParameterValue("source_addr_ton"))
                .SetParameterValue("dest_addr_npi", objRequestPDU.GetParameterValue("source_addr_npi"))
                .SetParameterValue("destination_addr", objRequestPDU.GetParameterValue("source_addr"))
                .SetParameterValue("esm_class", 0) ' Default messaging mode (S&F), default msg type, default GSM features
                .SetParameterValue("protocol_id", 0)
                .SetParameterValue("priority_flag", 0)
                .SetParameterValue("schedule_delivery_time", "")
                .SetParameterValue("validity_period", "")
                .SetParameterValue("registered_delivery", 0)
                .SetParameterValue("replace_if_present_flag", 0)
                .SetParameterValue("data_coding", &H8UI) ' UCS-2
                .SetParameterValue("sm_default_msg_id", 0)
                '
                '   Convert message to UCS-2 encoding
                '
                Dim EncodedShortMessage = .ConvertToUCS2(ResponseMessage)
                If EncodedShortMessage.Length <= 254 Then
                    .SetParameterValue("short_message", EncodedShortMessage)
                Else
                    .SetParameterValue("short_message", EncodedShortMessage.Take(0).ToArray()) ' set to zero length byte array
                    .SetParameterValue("message_payload", EncodedShortMessage)
                End If
            End With
            '
            '   Done - return response PDU
            '
            TraceLine("ProcessDeliverSMRequest", "ResponsePDU = " & objResponsePDU.ToString())
            Return objResponsePDU
        Catch ex As Exception
            Throw New Exception("Error in ProcessDeliverSMRequest. " & ex.Message)
        End Try
    End Function

    Private Class RequestException
        Inherits Exception

        Public ErrorCode As Integer

        Public Sub New(ByVal ErrorCode As Integer)
            MyBase.New("Request format invalid (error code " & ErrorCode & ")")
            Me.ErrorCode = ErrorCode
        End Sub
    End Class

    Private Function GetParameterValue(ByVal Name As String) As String
        If mcolParameters.ContainsKey(Name) Then
            Return mcolParameters(Name)
        Else
            Throw New Exception("Request processor parameter " & Name & " has not been set")
        End If
    End Function

    Private Function GetParameterValue(ByVal Name As String, ByVal DefaultValue As String) As String
        If mcolParameters.ContainsKey(Name) Then
            Return mcolParameters(Name)
        Else
            Return DefaultValue
        End If
    End Function

    Protected Sub TraceLine(ByVal FunctionName As String, ByVal Message As String)
        modGeneral.TraceLine(TypeName(Me) & "." & FunctionName, Message)
    End Sub
End Class
