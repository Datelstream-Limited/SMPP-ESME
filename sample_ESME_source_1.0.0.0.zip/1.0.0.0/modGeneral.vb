﻿Module modGeneral

    Public TraceAppName As String = "tsstsesme" ' My.Application.Info.AssemblyName

    Public TraceEnabled As Boolean = False

    Public Sub TraceLine(ByVal FunctionName As String, ByVal Message As String)
        If TraceEnabled Then System.Diagnostics.Trace.WriteLine(TraceAppName & ": T" & System.Threading.Thread.CurrentThread.ManagedThreadId & " " & FunctionName & ": " & Message)
    End Sub

    Public Function BytesAsHex(ByVal buffer As Byte()) As String
        Dim Result As String = ""
        For Each b As Byte In buffer
            Result &= AsHex(b, 2)
        Next
        Return Result
    End Function

    Public Function AsHex(ByVal Value As UInt32, ByVal Digits As Integer) As String
        Dim Result As String = ""

        For Count As Integer = 1 To Digits
            Dim d As Integer = Value Mod 16
            If d < 10 Then
                Result = CStr(d) & Result
            Else
                Result = Chr(Asc("A") + d - 10) & Result
            End If
            Value = Value \ 16
        Next
        Return Result
    End Function
End Module
